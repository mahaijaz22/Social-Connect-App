# Social Connect App (Week 6)
    
## Features Added
- User Follow System
- Basic Messaging (Firestore)
- Post Editing & Deletion
- Bottom Navigation
- Media Upload in Posts
- Search Functionality
- Profile Updates (Name, Bio, Picture)
- Performance Optimizations

## Setup Instructions
1. Clone the repository or extract the ZIP file.
2. Open the project in **Android Studio**.
3. Configure Firebase in your project.
4. Sync Gradle and run the app on an emulator or device.

## Tech Stack
- Kotlin, Jetpack Compose
- Firebase Authentication, Firestore, Storage
- Android Navigation Component
